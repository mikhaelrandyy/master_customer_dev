from enum import Enum


class OrderEnumSch(str, Enum):
    ascendent = "ascendent"
    descendent = "descendent"
